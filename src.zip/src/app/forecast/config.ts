export const openWeatherMapKey = "bfd174941ada9859a0184db7a75e4db6";
export const apiURL = "http://api.openweathermap.org/data/2.5/";
